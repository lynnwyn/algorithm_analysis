import java.util.*;

public class Main {

	public static void main (String[] args) {
		// creating 100 instances of TSP
		TspProblem[] hundred = new TspProblem[100];
		for (int i = 0; i < 100; i++) {
			TspProblem seven = generate(7);
			hundred[i] = seven;
		}
		
		// solve with brute force
		double[] cost_b = new double[100];
		for (int i = 0; i < hundred.length; i++) {
			Solve test = new Solve(7);
			double result = test.BruteForce(hundred[i], 0);
			cost_b[i] = result;
		}
		
		System.out.println("Brute force");
		System.out.println("Maximum tour length over the 100 TSP instance is " + max(cost_b));
		System.out.println("Minimum tour length over the 100 TSP instance is " + min(cost_b));
		System.out.println("Mean tour length over the 100 TSP instance is " + mean(cost_b));
		System.out.println("Standard deviation of tour length over the 100 TSP instance is " + std(cost_b));
	
		// creating a tour starting from city with id 0
		// tour: 0 -> 1 -> 2 -> 3 -> 4 -> 5 -> 6
		ArrayList<Integer> tour = new ArrayList<Integer>();
		for (int i = 0; i < 7; i++)
			if (i != 0)
				tour.add(i);
		// to store all the randomly generated tour
		ArrayList<ArrayList<Integer>> tour_set = new ArrayList<ArrayList<Integer>>();
		
		// create a random tour by shuffle the above array list
		int count = 0;
		double[] cost_rdm = new double[100];
		for(int i=0;i<hundred.length;i++) {
			Collections.shuffle(tour);
			tour_set.add(tour);
			double acc = 0;
			double[][] dist = hundred[i].getDistance();
			int k = 0;
			for (int m = 0; m < tour.size(); m++) {
				acc += dist[k][tour.get(m)];
				k = tour.get(m);
			}
			cost_rdm[i] = acc;
			if(cost_rdm[i] == cost_b[i])
				count++;
		}
		
		System.out.println();
		
		System.out.println("Randomly generated tour");
		System.out.println("Maximum tour length over the randomly generated 100 TSP instance is " + max(cost_rdm));
		System.out.println("Minimum tour length over the randomly generated 100 TSP instance is " + min(cost_rdm));
		System.out.println("Mean tour length over the randomly generated 100 TSP instance is " + mean(cost_rdm));
		System.out.println("Standard deviation of tour length over the randomly generated 100 TSP instance is " + std(cost_rdm));
		System.out.println("There are "+count+" times that the randomly generated tour is the optimal tour.");
		
		double[] cost_greedy = new double[100];
		
		for(int i =0;i<100;i++) {
		
			ArrayList<Integer> vertex = tour_set.get(i);
			double re = twoSwap(hundred[i].getDistance(),0,vertex,cost_rdm[i]);
			cost_greedy[i] = re;
		}
		
		System.out.println("Using 2 swap");
		System.out.println("Maximum tour length over the 100 TSP instance is " + max(cost_greedy));
		System.out.println("Minimum tour length over the 100 TSP instance is " + min(cost_greedy));
		System.out.println("Mean tour length over the 100 TSP instance is " + mean(cost_greedy));
		System.out.println("Standard deviation of tour length over the 100 TSP instance is " + std(cost_greedy));
		
	}
	
	public static double twoSwap(double[][] dist, int s, ArrayList<Integer> vertex, Double cost) {
		double min = cost;
		boolean swaped = false;
		while(!swaped) {
			for(int i = 0; i<vertex.size();i++) {
				for(int j=1; j<=vertex.size();j++) {
					ArrayList<Integer> new_route = optSwap(vertex,i,j);
					double cur_cost = 0;
					int k = s;
					for (int p = 0; p < new_route.size(); p++) {
						cur_cost += dist[k][new_route.get(p)];
						k = new_route.get(i);
					}
					cur_cost += dist[k][s];
					if(cur_cost<min) {
						vertex = new_route;
						swaped = true;
						min = cur_cost;
					}
				}
			}
		}
		return min;
	}
	
	public static ArrayList<Integer> optSwap(ArrayList<Integer> route, int i, int k){
		ArrayList<Integer> output = new ArrayList<Integer>();
		for(int index =0 ;index<i;index++) {
			output.add(index,route.get(index));
		}
		int t = k-1;
		for(int index = i; index<k;index++) {
			output.add(index,route.get(t));
			t--;
		}
		for(int index = k; index<route.size();index++) {
			output.add(index,route.get(index));
		}
		return output;
	}
	
	// find min over an array
	public static double min(double[] input) {
		double min = input[0];
		for(int i=0; i<input.length; i++) {
			if(input[i]<min) {
				min = input[i];
			}
		}
		return min;
	}

	// find max over an array
	public static double max(double[] input) {
		double max = input[0];
		for (int i = 0; i < input.length; i++) {
			if (input[i] > max) {
				max = input[i];
			}
		}
		return max;
	}

	// find mean over an array
	public static double mean(double[] input) {
		double sum = 0;
		for (int i = 0; i < input.length; i++) {
			sum = sum+input[i];
		}
		return sum/input.length;
	}
	
	// find standard deviation over an array
	public static double std(double[] input) {
		double sos = 0;
		double mean = mean(input);
		for(int i = 0 ; i < input.length; i++) {
			double tmp = input[i]-mean;
			sos = sos + tmp*tmp;
		}
		double output = sos / (input.length-1);
		output = Math.sqrt(output);
		return output;
	}
	
	
	// generate a TspProblem with specific number of cities
	public static TspProblem generate(int num) {
		double[] xcor = new double[num];
		double[] ycor = new double[num];
		for(int i = 0;i<num;i++) {
			double x = Math.random()*(1.0-0.0)+0.0;
			xcor[i] = x;
			double y = Math.random()*(1.0-0.0)+0.0;
			ycor[i] = y;
		}
		TspProblem output = new TspProblem(xcor, ycor);
		return output;
	}

}