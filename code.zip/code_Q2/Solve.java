import java.util.*;

public class Solve {
	
	// attributes
	private int num; // number of city
//	private ArrayList<Tour> tours;  // list of all permutations and costs of each permutation
	private double[] costs;
	private ArrayList<ArrayList<Integer>> path;
	// constructor
	public Solve(int n) {
		this.num = n;
		this.path = new ArrayList<ArrayList<Integer>>();
	}
	
	public double[] getCost() {
		return this.costs;
	}

	public ArrayList<ArrayList<Integer>> getTours(){
		return this.path;
	} 

	public double BruteForce(TspProblem state, int s) {
		ArrayList<Integer> vertex = new ArrayList<Integer>();
		double[][] dist = state.getDistance();

		for (int i = 0; i < num; i++)
			if (i != s)
				vertex.add(i);
	
		double min_path = Double.MAX_VALUE;
		while (findNextPermutation(vertex)) {
			
			
			double current_pathweight = 0;
			int k = s;

			for (int i = 0; i < vertex.size(); i++) {
				current_pathweight += dist[k][vertex.get(i)];
				k = vertex.get(i);
			}
			current_pathweight += dist[k][s];


			min_path = Math.min(min_path, current_pathweight);
		}

		// return the optimal solution
		return min_path;

	}

	public static ArrayList<Integer> swap(ArrayList<Integer> data, int left, int right) {
		int temp = data.get(left);
		data.set(left, data.get(right));
		data.set(right, temp);
		return data;
	}

	public static ArrayList<Integer> reverse(ArrayList<Integer> data, int left, int right) {
// Reverse the sub-array 
		while (left < right) {
			int temp = data.get(left);
			data.set(left++, data.get(right));
			data.set(right--, temp);
		}

// Return the updated array 
		return data;
	}

	// Function to find the next permutation
	// of the given integer array
	public static boolean findNextPermutation(ArrayList<Integer> data) {
		// If the given dataset is empty
		// or contains only one element
		// next_permutation is not possible
		if (data.size() <= 1)
			return false;

		int last = data.size() - 2;

		// find the longest non-increasing
		// suffix and find the pivot
		while (last >= 0) {
			if (data.get(last) < data.get(last + 1)) {
				break;
			}
			last--;
		}

		// If there is no increasing pair
		// there is no higher order permutation
		if (last < 0)
			return false;

		int nextGreater = data.size() - 1;

		// Find the rightmost successor
		// to the pivot
		for (int i = data.size() - 1; i > last; i--) {
			if (data.get(i) > data.get(last)) {
				nextGreater = i;
				break;
			}
		}

		// Swap the successor and
		// the pivot
		data = swap(data, nextGreater, last);

		// Reverse the suffix
		data = reverse(data, last + 1, data.size() - 1);

		// Return true as the
		// next_permutation is done
		return true;
	}
}
