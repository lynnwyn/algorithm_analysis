
import java.util.*;

public class Node implements Comparable<Node>{
	// attributes
	public enum DIRECTIONS {up,down,left,right}
	
	private final int[][] state;
	private Node parent;

	private ArrayList<Node> children; 
	public String dir;
	public String childDir;
	
	public int moving;
	
	private int cost;
	private int depth;
	
	private int zeroRow;
	private int zeroCol;
	
	// constructor
	public Node(int[][] init_state) {
		this.state = init_state;
		this.dir = null;
		this.parent = null;
		this.cost = 0;
		this.depth = 1 ;
		this.children = new ArrayList<Node>();


		for (int i = 0; i<init_state.length;i++) {
			for (int j=0;j<init_state[i].length;j++) {
				if(init_state[i][j]==0) {
					this.zeroRow = i;
					this.zeroCol = j;
					break;
				}
			}
		}
		
	}
	
	public ArrayList<Node> getChildren(){
		return this.children;
	}
	
	public Node getParent() {
		return this.parent;
	}

	
	// check what actions we can take given a direction
	public boolean canMove(DIRECTIONS d) {
		switch(d){
        case up:
            if (zeroRow != 0) {
                return true;
            }
            break;
        case down:
            if (zeroRow != this.state.length - 1) {
                return true;
            }
            break;
        case left:
            if (zeroCol != 0) {
                return true;
            }
            break;
        case right:
            if (zeroCol != this.state[zeroRow].length - 1) {
                return true;
            }
            break;
    }
    return false;
	}
	
	// add a child to the list of children
	public void addChild(Node c) {
		this.children.add(c);
		c.parent = this;
		c.dir = this.childDir;
		c.cost = this.cost + 1;
		c.depth = this.depth + 1;
		c.moving = this.moving;
	}
	
	public int getMoving() {
		return this.moving;
	}
	
	
	public int getCost() {
		return this.cost;
	}
	
	public int getDepth() {
		return this.depth;
	}
	
    private void setTile(int r, int c, int tile, int[][] change) {
        change[r][c] = tile;
    }
    private int getTile(int r, int c, int[][]target) {
        return target[r][c];
    }

	
	public int[][] move(DIRECTIONS d) {
		int moved[][] = 
				new int [this.state.length][this.state[zeroRow].length];
		for(int i=0;i<this.state.length;i++)
			for(int j=0;j<this.state[i].length;j++)
				moved[i][j] = this.state[i][j];
		
        switch (d) {
            case up:
                int upper = getTile(zeroRow-1,zeroCol,this.state);
                setTile(zeroRow-1,zeroCol,0,moved);
                setTile(zeroRow,zeroCol,upper,moved);
   
                this.childDir = "up";
                this.moving = upper;
                return moved;
                
            case down:
            	int lower = getTile(zeroRow+1,zeroCol,this.state);
                setTile(zeroRow+1,zeroCol,0,moved);
                setTile(zeroRow,zeroCol,lower,moved);
         
                this.childDir = "down";
                this.moving = lower;
                return moved;
               
            case left:
            	int l = getTile(zeroRow,zeroCol-1,this.state);
                setTile(zeroRow,zeroCol-1,0,moved);
                setTile(zeroRow,zeroCol,l,moved);
           
                this.childDir = "left";
                this.moving = l;
                return moved;
                
            case right:
            	int r = getTile(zeroRow,zeroCol+1,this.state);
                setTile(zeroRow,zeroCol+1,0,moved);
                setTile(zeroRow,zeroCol,r,moved);
   
                this.childDir = "right";
                this.moving = r;
                return moved;
                
                default: return null;
        }
    }
	
	// build children node
	public void buildChildren() {
		DIRECTIONS[] strategy = 
			{DIRECTIONS.up, DIRECTIONS.down, DIRECTIONS.left, DIRECTIONS.right};
		for(int i=0;i<strategy.length;i++) {
			if(this.canMove(strategy[i])) {
				int[][] moved = move(strategy[i]);
				Node child = new Node(moved);
				this.addChild(child);

			}
		}
	}
	
    	public String printState() {
	StringBuilder output = new StringBuilder();
	for (int i = 0; i<this.state.length;i++) {
		for (int j=0;j<this.state[i].length;j++) {
			output.append(this.state[i][j]).append(" ");	
		}
		if (i != this.state.length-1) {
		output.append("\n");
		}
	}
	return output.append("\n--------\n").toString();
}
    	
    	public boolean equals(Object o ) {    
    		
    		if(!(o instanceof Node)) {
    			return false;
    		}
    		Node check = (Node) o;
    		
    		return check.printState().equals(this.printState());
    	}


		public int compareTo(Node o) {
			if (this.getMoving() < o.getMoving()) {
				return -1;
			}
			if (this.getMoving() > o.getMoving()) {
				return 1;
			}
			return 0;

		}
    	
}
