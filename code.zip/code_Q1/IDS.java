import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class IDS {
	private final Stack<Node> s = new Stack<>();
	private LinkedList<Node> visited = new LinkedList<>();

	public Node solve(Node start, Node goal, int max_depth) {
	for (int incDepth = 1; incDepth < max_depth; incDepth++) {
			s.push(start);
			while(!s.isEmpty()) {
				Node cur =s.pop();
				visited.add(cur);
				if(cur.equals(goal)) return cur;
				if(cur.getDepth()<incDepth) {
					cur.buildChildren();
					ArrayList<Node> children = cur.getChildren();
					Collections.sort(children);
					for(int i =0;i<children.size();i++) {
						if (!visited.contains(children.get(i))) {
							s.push(children.get(i));
						}
					}	
				}
			}
		}
	return null;
	}
}
