import java.util.*;

public class BFS {
	private final Queue<Node> q = new LinkedList<>();
	private LinkedList<Node> visited = new LinkedList<>();
	
	// given a initial state, want to reach the goal state
	public Node solve(Node start,Node goal) {
		q.add(start);
		while(!q.isEmpty()) {
			Node cur =q.poll();
			visited.add(cur);
			if(cur.equals(goal)) return cur;
			cur.buildChildren();
			ArrayList<Node> children = cur.getChildren();
			Collections.sort(children);
			for(int i =0;i<children.size();i++) {
				if (!visited.contains(children.get(i))) {
					q.add(children.get(i));
				}
			}
		}
		return null;
	}
}
