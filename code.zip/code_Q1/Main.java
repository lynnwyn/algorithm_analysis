import java.util.ArrayList;

public class Main {
	public static void main (String[] args) {
		
		long timeStart_dfs;
        long timeStop_dfs;
        
        long timeStart_bfs;
        long timeStop_bfs;
        
        long timeStart_uni;
        long timeStop_uni;
        
        long timeStart_ids;
        long timeStop_ids;
		
		int[][] start = {{1,4,2},{5,3,0}};
		int[][] goal = {{0,1,2},{5,4,3}};
		Node s = new Node(start);
		Node g = new Node(goal);
		
		timeStart_bfs = System.nanoTime();
		BFS solve = new BFS();
		Node nbfs = solve.solve(s,g);
		timeStop_bfs = System.nanoTime();
		ArrayList<Node> pbfs = getPath(s,nbfs);
		
		
		timeStart_dfs = System.nanoTime();
		DFS dfs = new DFS();
		Node ndfs = dfs.solve(s,g);
		timeStop_dfs = System.nanoTime();
		ArrayList<Node> pdfs = getPath(s,ndfs);
		
		
		timeStart_uni = System.nanoTime();
		Uniform_cost uni = new Uniform_cost();
		Node nUni = uni.solve(s, g);
		timeStop_uni = System.nanoTime();
		ArrayList<Node> puni = getPath(s,nUni);	
		
		
		timeStart_ids = System.nanoTime();
		IDS ids = new IDS();
		Node nids = ids.solve(s,g,5);
		timeStop_ids = System.nanoTime();
		ArrayList<Node> pids = getPath(s,ndfs);
		
		
	//	System.out.println("DFS\n");
	//	printPath(pdfs);
	//	System.out.println("DFS depth is "+ndfs.getDepth());
	//	System.out.println("DFS time: "+(timeStop_dfs - timeStart_dfs));
		
	//	System.out.println("BFS\n");
	//	printPath(pbfs);
	//	System.out.println("BFS depth is "+nbfs.getDepth());
	//	System.out.println("BFS time: "+(timeStop_bfs - timeStart_bfs));
		
	//	System.out.println("Uniform cost\n");
	//	printPath(puni);
	//	System.out.println("Unifrom depth is "+nUni.getDepth());
	//	System.out.println("Uniform time: "+(timeStop_uni - timeStart_uni));
		
		System.out.println("IDS\n");
		printPath(pids);
		System.out.println("IDS depth is "+pids.get(0).getDepth());
		System.out.println("IDS time: "+(timeStop_ids - timeStart_ids));
		
	}
	
	public static ArrayList<Node> getPath(Node start, Node goal){
		Node tmp = goal;
		ArrayList<Node> output = new ArrayList<Node>();
		while(!(tmp.equals(start))) {
			output.add(tmp);
			tmp = tmp.getParent();
		}
		output.add(start);
		return output;
	}
	
	public static void printPath(ArrayList<Node> path) {
		int ct = 0;
		Node no = path.get(path.size()-1);
		System.out.println("Current State #"+ct+"\n"+no.printState()); 
		for(int i=path.size()-2;i>=0;i--) {
			ct++;
			Node n = path.get(i);
			System.out.println("Move blank spot to the "+n.dir);
			System.out.println();
			System.out.println("Current State #"+ct+"\n"+n.printState());
		}
		System.out.println("Goal reached!");
	}
}
