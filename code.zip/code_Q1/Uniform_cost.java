import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class Uniform_cost {
	private class custComparator implements Comparator<Node>{
		
		  public int compare(Node a, Node b) {
			    if (a.getCost() <= b.getCost()) {
		            return -1;
		        }
		        if (a.getCost() > b.getCost()) {
		            return 1;
		        }
		        return 0;
		  }
		 }
	
			private final PriorityQueue<Node> pq = new PriorityQueue<>(new custComparator());
			private LinkedList<Node> visited = new LinkedList<>();

			public Node solve(Node start, Node goal) {
				pq.add(start);
				while (!pq.isEmpty()) {
					Node cur = pq.poll();
					if (!visited.contains(cur)) {
						visited.add(cur);
						if (cur.equals(goal))
							return cur;
						cur.buildChildren();
						ArrayList<Node> children = cur.getChildren();
						Collections.sort(children);
						for (int i = 0; i < children.size(); i++) {
							if (!visited.contains(children.get(i))) {
								pq.add(children.get(i));
							}
						}
					}
				}
				return null;
			}
	
	
	
}
