import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class DFS {
	private final Stack<Node> s = new Stack<>();
	private LinkedList<Node> visited = new LinkedList<>();

	public Node solve(Node start, Node goal) {

		s.push(start);
		while (!s.isEmpty()) {
			Node cur = s.pop();
			if (cur.equals(goal))
				return cur;
			if (!visited.contains(cur)) {
				visited.add(cur);
				if (cur.equals(goal))
					return cur;
				cur.buildChildren();
				ArrayList<Node> children = cur.getChildren();
				Collections.sort(children);
				for (int i = 0; i < children.size(); i++) {
					if (!visited.contains(children.get(i))) {
						s.push(children.get(i));
					}
				}
			}
		}
		return null;
	}
	
	
}
